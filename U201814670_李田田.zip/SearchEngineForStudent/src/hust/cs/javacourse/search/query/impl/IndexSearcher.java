package hust.cs.javacourse.search.query.impl;

import hust.cs.javacourse.search.index.AbstractPosting;
import hust.cs.javacourse.search.index.AbstractPostingList;
import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.query.AbstractHit;
import hust.cs.javacourse.search.query.AbstractIndexSearcher;
import hust.cs.javacourse.search.query.Sort;
import hust.cs.javacourse.search.util.Config;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
/**
 * AbstractIndexSearcher 的具体实现类
 */
public class IndexSearcher extends AbstractIndexSearcher {
    /**
     * 从指定索引文件打开索引，加载到index对象里. 一定要先打开索引，才能执行search方法
     *
     * @param indexFile ：指定索引文件
     */
    @Override
    public void open(String indexFile) {
        this.index.load(new File(indexFile));
        this.index.optimize();
    }

    /**
     * 根据单个检索词进行搜索
     *
     * @param queryTerm ：检索词
     * @param sorter    ：排序器
     * @return ：命中结果数组
     */
    @Override
    public AbstractHit[] search(AbstractTerm queryTerm, Sort sorter) {
        if (Config.IGNORE_CASE) {//忽略大小写
            String content = queryTerm.getContent().toLowerCase();
            queryTerm.setContent(content);
        }
        AbstractPostingList SearchPostingList = this.index.search(queryTerm);//查找检索词
        if (SearchPostingList == null) {//查找失败
            return null;
        }
        List<AbstractHit> getResult = new ArrayList<>();
        for (int i = 0; i < SearchPostingList.size(); i++) {
            AbstractPosting posting = SearchPostingList.get(i);
            AbstractHit hit = new Hit(posting.getDocId(), this.index.getDocName(posting.getDocId()));
            //对于该词的postinglist的每个posting构造hit
            hit.getTermPostingMapping().put(queryTerm, posting);//添加命中的单词和对应的Posting键值对
            hit.setScore(sorter.score(hit));//计算分数
            getResult.add(hit);//将该hit加入hit队列
        }
        sorter.sort(getResult);//查询结果排序
        AbstractHit[] result = new AbstractHit[getResult.size()];
        return getResult.toArray(result);
    }

    /**
     * 根据二个检索词进行搜索
     *
     * @param queryTerm1 ：第1个检索词
     * @param queryTerm2 ：第2个检索词
     * @param sorter     ：    排序器
     * @param combine    ：   多个检索词的逻辑组合方式
     * @return ：命中结果数组
     */
    @Override
    public AbstractHit[] search(AbstractTerm queryTerm1, AbstractTerm queryTerm2, Sort sorter, AbstractIndexSearcher.LogicalCombination combine) {
        AbstractPostingList SearchPostingList1 = index.search(queryTerm1);
        AbstractPostingList SearchPostingList2 = index.search(queryTerm2);
        if (SearchPostingList1 == null && SearchPostingList2 == null) {// 如果两个都没找到返回null
            return null;
        }
        List<AbstractHit> getResult = new ArrayList<>();
        if (combine == LogicalCombination.AND) {
            if (SearchPostingList1 == null || SearchPostingList2 == null) {// 如果有一个词语根本就不存在，那就返回null
                return null;
            }
            for (int i = 0; i < SearchPostingList1.size(); i++) {
                int docId = SearchPostingList1.get(i).getDocId();
                int searchDocId = SearchPostingList2.indexOf(docId);
                if (searchDocId != -1) {//单词1和单词2在同一个文件中出现
                    AbstractHit hit = new Hit(docId, this.index.getDocName(docId));
                    //对于该词的postinglist的每个posting构造hit
                    hit.getTermPostingMapping().put(queryTerm1, SearchPostingList1.get(i));//添加命中的单词1和对应的Posting键值对
                    hit.getTermPostingMapping().put(queryTerm2, SearchPostingList2.get(SearchPostingList2.indexOf(docId)));//添加命中的单词2和对应的Posting键值对
                    hit.setScore(sorter.score(hit));//计算分数
                    getResult.add(hit);//将该hit加入hit队列
                }
            }
        }
        else if (combine == LogicalCombination.OR) {
            if (SearchPostingList1 == null) {// 如果有一个不存在直接对另外一个进行搜索
                return search(queryTerm2, sorter);
            }
            if (SearchPostingList2 == null) {
                return search(queryTerm1, sorter);
            }
            for (int i = 0; i < SearchPostingList1.size(); i++) {
                AbstractPosting posting1 = SearchPostingList1.get(i);
                int docId = SearchPostingList1.get(i).getDocId();
                int sub_index = SearchPostingList2.indexOf(docId);
                AbstractHit hit;
                if (sub_index == -1) {//一个文件中只出现单词1
                    hit = new Hit(posting1.getDocId(), this.index.getDocName(posting1.getDocId()));
                    //对于该词的postinglist的每个posting构造hit
                    hit.getTermPostingMapping().put(queryTerm1, posting1);//添加命中的单词和对应的Posting键值对
                    hit.setScore(sorter.score(hit));//计算分数
                    getResult.add(hit);//将该hit加入hit队列
                } else {//出现单词1和单词2
                    hit = new Hit(docId, this.index.getDocName(docId));
                    //对于该词的postinglist的每个posting构造hit
                    hit.getTermPostingMapping().put(queryTerm1, posting1);//添加命中的单词1和对应的Posting键值对
                    hit.getTermPostingMapping().put(queryTerm2, SearchPostingList2.get(SearchPostingList2.indexOf(docId)));//添加命中的单词2和对应的Posting键值对
                    hit.setScore(sorter.score(hit));//计算分数
                    getResult.add(hit);//将该hit加入hit队列
                }
            }
            for (int i = 0; i < SearchPostingList2.size(); i++) {
                AbstractPosting posting2 = SearchPostingList2.get(i);
                int docId2 = SearchPostingList2.get(i).getDocId();
                int sub_index2 = SearchPostingList1.indexOf(docId2);
                if (sub_index2 == -1) {//一个文件中只出现单词2
                    AbstractHit hit = new Hit(docId2, this.index.getDocName(docId2));
                    //对于该词的postinglist的每个posting构造hit
                    hit.getTermPostingMapping().put(queryTerm2, posting2);//添加命中的单词和对应的Posting键值对
                    hit.setScore(sorter.score(hit));//计算分数
                    getResult.add(hit);//将该hit加入hit队列
                }
            }
        }
        sorter.sort(getResult);//查询结果排序
        AbstractHit[] result = new AbstractHit[getResult.size()];
        return getResult.toArray(result);
    }

}
