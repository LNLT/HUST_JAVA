package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleFilter;
import hust.cs.javacourse.search.parse.AbstractTermTupleStream;
import hust.cs.javacourse.search.util.Config;
/**
 * AbstractTermTupleFilter 的具体实现类,基于长度过滤
 */
public class LengthTermTupleFilter extends AbstractTermTupleFilter {
    /**
     * @param input Filter的输入,类型为AbstractTermTupleStream
     */
    public LengthTermTupleFilter(AbstractTermTupleStream input) {
        super(input);//调用父类含参数string的构造函数
    }

    /**
     * 获得下一个三元组
     *
     * @return 下一个三元组；如果到了流的末尾，返回null
     */
    @Override//对父类一个方法的重写覆盖
    public AbstractTermTuple next() {
        AbstractTermTuple nextTuple = input.next();
        if (nextTuple == null)
            return null;
        while (nextTuple.term.getContent().length() > Config.TERM_FILTER_MAXLENGTH || nextTuple.term.getContent().length() < Config.TERM_FILTER_MINLENGTH) {
            nextTuple = input.next();
            if (nextTuple == null)
                return null;
        }
        return nextTuple;
    }
}
