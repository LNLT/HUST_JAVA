package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleFilter;
import hust.cs.javacourse.search.parse.AbstractTermTupleStream;
import hust.cs.javacourse.search.util.StopWords;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * AbstractTermTupleFilter 的具体实现类,基于停用词过滤
 */
public class StopWordTermTupleFilter extends AbstractTermTupleFilter {
    private List<String> stopWordList;

    /**
     * @param input Filter的输入,类型为AbstractTermTupleStream
     */
    public StopWordTermTupleFilter(AbstractTermTupleStream input) {
        super(input);//调用父类含参数string的构造函数
        this.stopWordList = new ArrayList<>(Arrays.asList(StopWords.STOP_WORDS));
        //stopWordList 将停用词转换为列表付给列表参数
    }

    /**
     * 获得下一个三元组
     *
     * @return 下一个三元组；如果到了流的末尾，返回null
     */
    @Override//对父类一个方法的重写覆盖
    public AbstractTermTuple next() {
        AbstractTermTuple nextTuple = input.next();
        if (nextTuple == null)
            return null;
        while (stopWordList.contains(nextTuple.term.getContent())) {
            nextTuple = input.next();
            if (nextTuple == null)
                return null;
        }
        return nextTuple;
    }
}
