package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.index.impl.TermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleScanner;
import hust.cs.javacourse.search.util.Config;
import hust.cs.javacourse.search.util.StringSplitter;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
/**
 * AbstractTermTupleScanner 的具体实现类
 */
public class TermTupleScanner extends AbstractTermTupleScanner {
    Queue<AbstractTermTuple> getTuple = new LinkedList<>();
    int pos = 0;

    /**
     * 缺省构造函数
     */
    public TermTupleScanner() {
    }

    /**
     * 构造函数
     *
     * @param input：输入流对象
     */
    public TermTupleScanner(BufferedReader input) {
        super(input);//调用父类含参数string的构造函数

    }

    /**
     * 获得下一个三元组
     *
     * @return 下一个三元组；如果到了流的末尾，返回null
     */
    @Override
    public AbstractTermTuple next() {
        if (getTuple.isEmpty()) {//如果队列为空
            try {
                String read = input.readLine();//读取下一行
                while (read != null && read.length() == 0) {//遇到空行时，继续读
                    read = input.readLine();
                }
                if (read == null)//读到文件尾时，返回
                    return null;
                StringSplitter splitter = new StringSplitter();
                splitter.setSplitRegex(Config.STRING_SPLITTER_REGEX);
                for (String key : splitter.splitByRegex(read)) {
                    AbstractTermTuple next = new TermTuple(key, pos);
                    /*
                    AbstractTermTuple next = new TermTuple();
                    next.curPos = pos;
                    错误：next的term为空，下面却直接调用了
                    */
                    if (Config.IGNORE_CASE) {
                        next.term.setContent(key.toLowerCase());
                    } else
                        next.term.setContent(key);
                    getTuple.add(next);
                    pos++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return getTuple.poll();//检索队列的head元素，然后删除队列的head元素
    }
}
