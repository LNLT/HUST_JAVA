package hust.cs.javacourse.search.run;

import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.index.impl.Term;
import hust.cs.javacourse.search.query.AbstractHit;
import hust.cs.javacourse.search.query.AbstractIndexSearcher;
import hust.cs.javacourse.search.query.impl.IndexSearcher;
import hust.cs.javacourse.search.query.impl.SimpleSorter;
import hust.cs.javacourse.search.util.Config;

import java.util.Scanner;

import static hust.cs.javacourse.search.util.FileUtil.write;

/**
 * 测试搜索
 */
public class TestSearchIndex {
    /**
     * 搜索程序入口
     *
     * @param args ：命令行参数
     */
    public static void main(String[] args) {
        IndexSearcher searcher = new IndexSearcher();
        SimpleSorter sorter = new SimpleSorter();
        searcher.open(Config.INDEX_DIR + "Index.txt");
        Scanner input = new Scanner(System.in);
        StringBuffer searchHits;
        AbstractHit[] hits;
        int choice = 1;
        while (choice != 0) {
            System.out.println("0. exit.");
            System.out.println("1. search term.");
            System.out.println("2. search term1 combine term2.");
            System.out.println("input：");
            choice = input.nextInt();
            switch (choice) {
                case 0:
                    System.out.println("exit.");
                    break;
                case 1:
                    System.out.println("input term：");
                    AbstractTerm term = new Term();
                    term.setContent(input.next());
                    hits = searcher.search(term, sorter);
                    if (hits == null) {
                        System.out.println("the term can't find");
                        break;
                    }
                    searchHits = new StringBuffer();
                    for (AbstractHit hit : hits) {
                        System.out.println(hit.toString());
                        searchHits.append(hit.toString());
                    }
                    String search1 = new String(searchHits);
                    write(search1, Config.INDEX_DIR + "search1.txt");
                    break;
                case 2:
                    System.out.println("input term1 combine term2：");
                    AbstractTerm term1 = new Term();
                    AbstractTerm term2 = new Term();
                    input.nextLine();
                    String get = input.nextLine();
                    String[] getSingle = get.split(" ");
                    if (getSingle.length != 3) {
                        System.out.println("input error!");
                        break;
                    }
                    term1.setContent(getSingle[0]);
                    term2.setContent(getSingle[2]);
                    if (getSingle[1].equals("and")) {
                        hits = searcher.search(term1, term2, sorter, AbstractIndexSearcher.LogicalCombination.AND);
                        if (hits == null) {
                            System.out.println("the term can't find");
                        } else {
                            searchHits = new StringBuffer();
                            for (AbstractHit hit : hits) {
                                System.out.println(hit.toString());
                                searchHits.append(hit.toString());
                            }
                            String search2 = new String(searchHits);
                            write(search2, Config.INDEX_DIR + "search2.txt");
                        }
                    } else if (getSingle[1].equals("or")) {
                        hits = searcher.search(term1, term2, sorter, AbstractIndexSearcher.LogicalCombination.OR);
                        if (hits == null) {
                            System.out.println("the term can't find");
                        } else {
                            searchHits = new StringBuffer();
                            for (AbstractHit hit : hits) {
                                System.out.println(hit.toString());
                                searchHits.append(hit.toString());
                            }
                            String search3 = new String(searchHits);
                            write(search3, Config.INDEX_DIR + "search2.txt");
                        }
                    }
                    break;
                default:
                    System.out.println("input error!");
                    break;
            }
        }
    }
}
