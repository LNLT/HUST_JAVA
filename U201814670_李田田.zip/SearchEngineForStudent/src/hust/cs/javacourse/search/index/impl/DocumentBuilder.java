package hust.cs.javacourse.search.index.impl;

import hust.cs.javacourse.search.index.AbstractDocument;
import hust.cs.javacourse.search.index.AbstractDocumentBuilder;
import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleStream;
import hust.cs.javacourse.search.parse.impl.*;

import java.io.*;
/**
 * AbstractDocumentBuilder的具体实现类
 */
public class DocumentBuilder extends AbstractDocumentBuilder {
    /**
     * <pre>
     * 由解析文本文档得到的TermTupleStream,构造Document对象.
     * @param docId             : 文档id
     * @param docPath           : 文档绝对路径
     * @param termTupleStream   : 文档对应的TermTupleStream
     * @return ：Document对象
     * </pre>
     */
    @Override
    public AbstractDocument build(int docId, String docPath, AbstractTermTupleStream termTupleStream) {
        AbstractDocument document = new Document(docId, docPath);
        AbstractTermTuple next_termTuple = termTupleStream.next();
        while (next_termTuple != null) {
            document.addTuple(next_termTuple);
            next_termTuple = termTupleStream.next();
        }
        return document;
    }

    /**
     * <pre>
     * 由给定的File,构造Document对象.
     * 该方法利用输入参数file构造出AbstractTermTupleStream子类对象后,内部调用
     *      AbstractDocument build(int docId, String docPath, AbstractTermTupleStream termTupleStream)
     * @param docId     : 文档id
     * @param docPath   : 文档绝对路径
     * @param file      : 文档对应File对象
     * @return          : Document对象
     * </pre>
     */
    public AbstractDocument build(int docId, String docPath, File file) {
        AbstractTermTupleStream inStream = null;
        AbstractDocument document = null;
        try {
            FileInputStream fileIn = new FileInputStream(file);
            InputStreamReader input = new InputStreamReader(fileIn);
            BufferedReader buf = new BufferedReader(input);
            inStream = new TermTupleScanner(buf);
            inStream = new StopWordTermTupleFilter(inStream); //再加上停用词过滤器
            inStream = new PatternTermTupleFilter(inStream); //再加上正则表达式过滤器
            inStream = new LengthTermTupleFilter(inStream); //再加上单词长度过滤器
            document = this.build(docId, docPath, inStream);
        } catch (IOException e) {
            e.printStackTrace();
        }//错误：没有对inStream进行赋值
        return document;
    }
}
