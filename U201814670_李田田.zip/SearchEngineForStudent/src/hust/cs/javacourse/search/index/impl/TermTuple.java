package hust.cs.javacourse.search.index.impl;

import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.index.AbstractTermTuple;
/**
 * AbstractTermTuple 的具体实现类
 */
public class TermTuple extends AbstractTermTuple {
    public TermTuple() {
    }

    /**
     * @param term   ：单词
     * @param curPos ：位置
     */
    public TermTuple(AbstractTerm term, int curPos) {
        this.term = term;
        this.curPos = curPos;
        //this.freq不用等，因为其不能被子类覆盖
    }

    /**
     * @param content ：单词内容
     * @param curPos  ：位置
     */
    public TermTuple(String content, int curPos) {
        this.term = new Term();
        this.term.setContent(content);
        this.curPos = curPos;
    }

    /**
     * 判断二个三元组内容是否相同
     *
     * @param obj ：要比较的另外一个三元组
     * @return 如果内容相等（三个属性内容都相等）返回true，否则返回false
     */
    @Override
    public boolean equals(Object obj) {//错误：比较相等之前必须进行类型的比较和转换
        if (obj instanceof AbstractTermTuple) {//instanceof比较两个类型是否一致
            TermTuple tuple=(TermTuple) obj;
            return this.curPos == tuple.curPos && this.freq == tuple.freq && this.term.equals(tuple.term);
        }
        return false;
    }

    /**
     * 获得三元组的字符串表示
     *
     * @return ： 三元组的字符串表示
     */
    @Override
    public String toString() {
        return "{term:" + this.term.toString() + " " + "freq:" + this.freq + " " + "curPos:" + this.curPos + "}";
    }
}
