package hust.ltt.num_add;

import java.util.Scanner;
/**
 * 读取一个0-1000之间的整数，并将该整数的各位数字相加
 */
public class work {
    public static void main(String[] args){
        System.out.print("Enter a number between 0 and 1000: ");
        Scanner input = new Scanner(System.in);
        int num = input.nextInt();
        if(num >= 0 && num < 1000){
            int s0 = num % 10;
            int s1 = (num / 10) % 10;
            int s2 = num / 100;
            System.out.print("The sum of the digits is ");
            System.out.println(s0+s1+s2);
        }
        else
            System.out.print("The number is illegal!");
    }
}
