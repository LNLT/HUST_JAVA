package hust.cs.ltt;

class Fan {
    final int SLOW = 1;
    final int MEDIUM = 2;
    final int FAST = 3;
    private int speed = SLOW;
    private boolean on = false;
    private double radius=5.0;
    String color="blue";
    public int getSpeed(){
        return this.speed;
    }
    public boolean getOn(){
        return this.on;
    }
    public double getRadius(){
        return this.radius;
    }
    public String getColor(){
        return this.color;
    }
    public void setSpeed(int speed){
        this.speed=speed;
    }
    public void setOn(boolean on){
        this.on=on;
    }
    public void setRadius(double radius){
        this.radius=radius;
    }
    public void setColor(String color){
        this.color=color;
    }
    public Fan(){
    }
    public String toString(){
        if(this.on){
            return "speed:"+this.speed+" color:"+this.color+" radius:"+this.radius;
        }
        else{
            return "fan is off!\tcolor:"+this.color+" radius:"+this.radius;
        }
    }
}
public class testFan{
    public static void main(String[] args){
        Fan fan1=new Fan();
        Fan fan2=new Fan();
        fan1.setSpeed(fan1.FAST);
        fan1.setRadius(10);
        fan1.setColor("yellow");
        fan1.setOn(true);
        System.out.println("fan1: "+fan1.toString());
        fan2.setSpeed(fan2.MEDIUM);
        fan2.setRadius(5);
        fan2.setColor("blue");
        fan2.setOn(false);
        System.out.println("fan2: "+fan2.toString());
    }

}