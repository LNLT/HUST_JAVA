package homework.ch11_13.p3;

import java.util.Objects;

public class Person implements Cloneable{
    private int age;
    private String name;//姓名

    /**
     * 缺省构造函数
     */
    public Person() {

    }

    /**
     * 构造函数
     */
    public Person(String name, int age) {
        this.age = age;
        this.name = name;
    }

    /**
     * Person的深拷贝克隆
     *
     * @return 拷贝克隆
     */
    @Override
    public Object clone() throws CloneNotSupportedException{
        Person person = (Person) super.clone();
        person.setAge(this.age);
        person.setName(new String(this.name));
        return person;
    }


    /**
     * 比较二个Person对象的内容是否相等
     *
     * @param obj  对象
     * @return 是否相等
     */
    public boolean equals(Object obj) {
        if(obj instanceof Person){
            Person person = (Person) obj;
            return this.age == person.getAge() && Objects.equals(this.name, person.getName());
        }
        return false;
    }


    /**
     * 获取年龄
     *
     * @return 年龄
     */
    public int getAge() {
        return this.age;
    }


    /**
     * 获取姓名
     *
     * @return 姓名
     */
    public String getName() {
        return this.name;
    }


    /**
     * 设置年龄
     *
     * @param age 年龄
     */
    public void setAge(int age) {
        this.age = age;
    }


    /**
     * 设置姓名
     *
     * @param name 姓名
     */
    public void setName(String name) {
        this.name = name;
    }


    /**
     * 覆盖toString
     *
     * @return String
     */
    public String toString() {
        return "name:" + this.name + " age:" + this.age;
    }

}
