package homework.ch11_13.p3;

import java.util.Objects;

public class Student extends Person implements Cloneable {
    private String classNo;//所在班级
    private String department;//所在院系
    private int studentId;//学生Id

    /**
     * 缺省构造函数
     */
    public Student() {

    }

    /**
     * 构造函数
     */
    public Student(String name, int age, int studentId, String department, String classNo) {
        super(name, age);
        this.classNo = classNo;
        this.studentId = studentId;
        this.department = department;
    }

    /**
     * Student的深拷贝克隆
     */
    public Object clone() throws CloneNotSupportedException {
        Student student = (Student) super.clone();
        student.studentId = this.studentId;
        student.classNo = new String(this.getClassNo());
        student.department = new String(this.getDepartment());
        return student;
    }

    /**
     * 比较二个Student对象的内容是否相等
     *
     * @param obj 对象
     * @return 是否相等
     */
    public boolean equals(Object obj) {
        if (super.equals(obj)) {
            if (obj instanceof Student) {
                Student student = (Student) obj;
                return student.studentId == this.studentId && Objects.equals(student.department, this.department) && Objects.equals(student.classNo, this.classNo);
            }
        }
        return false;
    }

    /**
     * 获取所在班级
     *
     * @return 所在班级
     */
    public String getClassNo() {
        return this.classNo;
    }

    /**
     * 获取所在院系
     *
     * @return 所在院系
     */
    public String getDepartment() {
        return this.department;
    }

    /**
     * 获取学生Id
     *
     * @return 学生Id
     */
    public int getStudentId() {
        return this.studentId;
    }

    /**
     * 设置所在班级
     *
     * @param classNo 所在班级
     */
    public void setClassNo(String classNo) {
        this.classNo = classNo;
    }

    /**
     * 设置所在院系
     *
     * @param department 所在院系
     */
    public void setDepartment(String department) {
        this.department = department;
    }

    /**
     * 设置学生Id
     *
     * @param studentId studentId
     */
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    /**
     * 覆盖toString
     *
     * @return String
     */
    public String toString() {
        return super.toString() + " studentId:" + this.studentId + " department:" + this.department + " classNo:" + this.classNo;
    }

}
