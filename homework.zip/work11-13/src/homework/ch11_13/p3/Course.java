package homework.ch11_13.p3;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Course implements Cloneable {
    private String courseName;
    private List<Person> students = new ArrayList<>();
    private Person teacher;

    public Course(String courseName, Person teacher) {
        this.courseName = courseName;
        this.teacher = teacher;
    }

    /**
     * Course的深拷贝克隆
     *
     * @return 拷贝克隆
     */
    public Object clone() throws CloneNotSupportedException {
        Course course = (Course) super.clone();
        List<Person> list = new ArrayList<Person>();
        for (Person s : this.students) {
            Person person=(Person) s.clone();
            list.add(person);
        }
        course.courseName = new String(this.courseName);
        course.teacher = (Faculty) (this.teacher.clone());
        course.students = list;
        return course;
    }

    /**
     * 比较二个Course对象的内容是否相等
     *
     * @param obj 对象
     * @return 比较二个Course对象的内容是否相等
     */
    public boolean equals(Object obj) {
        if (obj instanceof Course) {
            Course course = (Course) obj;
            if (course.students == null && this.students == null) {
                return course.courseName.equals(this.courseName) && course.teacher.equals(this.teacher);
            } else if (course.students != null && this.students != null) {
                return Objects.equals(course.courseName,this.courseName) && course.teacher.equals(this.teacher) && course.students.size() == this.students.size() && course.students.containsAll(this.students);
            }
        }
        return false;
    }

    /**
     * 获取课程名称
     *
     * @return 课程名称
     */
    public String getCourseName() {
        return this.courseName;
    }

    /**
     * 获取选修课程的学生总数
     *
     * @return 学生总数
     */
    public int getNumberOfStudent() {
        return this.students.size();
    }

    /**
     * 获取课程的学生名单 这个方法纯粹是为了测试课程对象的深拷贝。
     *
     * @return 学生名单
     */
    public List<Person> getStudents() {
        return this.students;
    }

    /**
     * 获取课程授课老师
     *
     * @return 课程授课老师
     */
    public Person getTeacher() {
        return this.teacher;
    }

    /**
     * 选修课程。
     *
     * @param s 学生
     */
    public void register(Person s) {
        if (!this.students.contains(s)) {
            this.students.add(s);
        }
    }

    /**
     * 覆盖toString
     *
     * @return String
     */
    public String toString() {
        StringBuffer course = new StringBuffer();
        course.append("courseName:" + this.courseName + " teacher:" + this.teacher+"\n");
        for (Person s : this.students) {
            course.append(s.toString()+"\n");
        }
        return new String(course);
    }

    /**
     * 取消选修 应该把取消选修的学生从学生名单里删除
     *
     * @param s 取消选修的学生
     */
    public void unregister(Person s) {
        if (this.students != null && this.students.contains(s)) {
            this.students.remove(s);
        }
    }

}
