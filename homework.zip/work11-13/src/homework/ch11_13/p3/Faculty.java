package homework.ch11_13.p3;

import java.util.Objects;

public class Faculty extends Person implements Cloneable {
    private String email;//邮箱
    private int facultyId;//教工Id
    private String title;//职称

    public Faculty() {

    }

    /**
     * 缺省构造函数
     */
    public Faculty(String name, int age, int facultyId, String title, String email) {
        super(name, age);
        this.email = email;
        this.facultyId = facultyId;
        this.title = title;
    }

    /**
     * Faculty的深拷贝克隆
     *
     * @return 深拷贝克隆
     */
    public Object clone() throws CloneNotSupportedException{
        Faculty faculty=(Faculty) super.clone();
        faculty.facultyId=this.facultyId;
        faculty.title=new String(this.title);
        faculty.email=new String(this.email);
        return faculty;
    }

    /**
     * 比较二个Faculty对象的内容是否相等
     *
     * @param obj 对象
     * @return 对象的内容是否相等
     */
    public boolean equals(Object obj) {
        if (super.equals(obj)) {
            if (obj instanceof Faculty) {
                Faculty faculty = (Faculty) obj;
                return faculty.facultyId == this.facultyId && Objects.equals(faculty.title,this.title) && Objects.equals(faculty.email,this.email);
            }
        }
        return false;
    }

    /**
     * 获取邮箱
     *
     * @return 邮箱
     */
    public String getEmail() {
        return this.email;
    }


    /**
     * 获取教工Id
     *
     * @return 教工Id
     */
    public int getFacultyId() {
        return this.facultyId;
    }


    /**
     * 获取职称
     *
     * @return 职称
     */
    public String getTitle() {
        return this.title;
    }


    /**
     * 设置邮箱
     *
     * @param email 邮箱
     */
    public void setEmail(String email) {
        this.email = email;
    }


    /**
     * 设置教工Id
     *
     * @param facultyId 教工Id
     */
    public void setFacultyId(int facultyId) {
        this.facultyId = facultyId;
    }


    /**
     * 设置职称
     *
     * @param title 职称
     */
    public void setTitle(String title) {
        this.title = title;
    }


    /**
     * 覆盖toString
     *
     * @return String
     */
    public String toString() {
        return super.toString()+" facultyId:"+this.facultyId+" title:"+this.title+" email:"+this.email;
    }

}
