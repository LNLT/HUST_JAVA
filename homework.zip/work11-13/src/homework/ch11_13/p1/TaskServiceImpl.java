package homework.ch11_13.p1;

import java.util.ArrayList;
import java.util.List;

class Task1 implements Task{
    public Task1(){

    }
    @Override
    public void execute(){
        System.out.println("first class:Task1");
    }
}

class Task2 implements Task{
    public Task2(){

    }
    @Override
    public void execute(){
        System.out.println("second class:Task2");
    }
}
class Task3 implements Task{
    public Task3(){

    }
    @Override
    public void execute(){
        System.out.println("third class:Task3");
    }
}

public class TaskServiceImpl {
    List<Task> listTasks= new ArrayList<>();
    /**
     * 执行任务接口列表中的每个任务
     */
    public void exeuteTasks(){
        for(Task t: listTasks){
            t.execute();
        }
    }
    /**
     * 添加任务
     * @param t 新添加的任务
     */
    public void addTask(Task t){
        listTasks.add(t);
    }
    public static void main(String[] args){
        System.out.println("-------test three Task!");
        Task1 task1 = new Task1();
        task1.execute();
        Task2 task2 =new Task2();
        task2.execute();
        Task3 task3 =new Task3();
        task3.execute();
        System.out.println("-------test TaskService!");
        TaskServiceImpl taskService = new TaskServiceImpl();
        taskService.addTask(task1);
        taskService.addTask(task2);
        taskService.addTask(task3);
        taskService.exeuteTasks();
    }
}

