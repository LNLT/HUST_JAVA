package homework.ch11_13.p4;

import java.util.ArrayList;

public class ComponentList extends ArrayList<Component> implements Iterator {
    private int position = -1;
    public ComponentList(){

    }
    /**
     * @return 是否还有元素
     */
    @Override
    public boolean hasNext(){
        return position + 1 < this.size();
    }
    /**
     * @return 获取下一个组件
     */
    @Override
    public Component next(){
        if(this.hasNext()){
            position++;
            return this.get(position);
        }else{
            return null;
        }
    }
}
