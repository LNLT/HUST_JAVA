package homework.ch11_13.p4;

abstract public class Component {
    protected int id;//组件的唯一id
    protected String name;//组件的名字
    protected double price;//组件的价格

    /**
     * 缺省构造函数
     */
    public Component() {
    }

    /**
     * 构造函数
     */
    public Component(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    /**
     * 添加子组件，对于没有子组件的AtomicComponent如内存条，调用这个方法应该抛出UnsupportedOperationException.
     *
     * @param component 添加子组件
     */
    public abstract void add(Component component) throws UnsupportedOperationException;

    /**
     * 计算组件的价格。
     *
     * @return 组件的价格
     */
    public abstract double calcPrice();

    /**
     * 基于组件id判断二个组件对象是否相等
     *
     * @param obj 组件对象
     * @return 组件对象是否相等
     */
    public boolean equals(Object obj) {
        if (obj instanceof Component) {
            Component component = (Component) obj;
            return component.id == this.id;
        }
        return false;
    }

    /**
     * 获取组件id
     *
     * @return 组件id
     */
    public int getId() {
        return this.id;
    }

    /**
     * 获取组件名称
     *
     * @return 组件名称
     */
    public String getName() {
        return this.name;
    }

    /**
     * 获取组件价格
     *
     * @return 组件价格
     */
    public double getPrice() {
        return this.calcPrice();
    }

    /**
     * 返回组件的迭代器
     *
     * @return 迭代器
     */
    public abstract Iterator iterator();

    /**
     * 删除子组件，对于没有子组件的AtomicComponent如内存条，调用这个方法应该抛出UnsupportedOperationException .
     *
     * @param component 子组件
     */
    public abstract void remove(Component component) throws UnsupportedOperationException;

    /**
     * 设置组件id
     *
     * @param id id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * 设置组件名称
     *
     * @param name 名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 设置组件价格
     *
     * @param price 价格
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * 返回组件的信息
     *
     * @return string
     */
    public String toString() {
        return "id:" + this.id + " name:" + this.name + " price:" + this.getPrice();
    }

}
