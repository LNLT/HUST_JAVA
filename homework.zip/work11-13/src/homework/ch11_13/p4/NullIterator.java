package homework.ch11_13.p4;

public class NullIterator implements Iterator{
    public NullIterator() {
    }
    /**
     * @return 是否还有元素
     */
    @Override
    public boolean hasNext(){
        return false;
    }
    /**
     * @return 获取下一个组件
     */
    @Override
    public Component next(){
        return null;
    }
}
