package homework.ch11_13.p4;

public class Test {
    public static void main(String[] args){
        //首先打印根节点
        Component computer = ComponentFactory.create();
        System.out.println(computer);
        System.out.println("id: " + computer.getId() + ", name: " +
                computer.getName() + ", price:" + computer.getPrice());
        Iterator it = computer.iterator(); // 首先得到迭代器
        while (it.hasNext()){
            Component c = it.next();
            //注意这里不能打印c.toString(), toString()方法会递归调用子组件的toString()
            System.out.println("id: " + c.getId() + ", name: " +
                    c.getName() + ", price:" + c.getPrice());
        }
    }
}
