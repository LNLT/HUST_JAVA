package homework.ch11_13.p4;

public class CompositeComponent extends Component {
    protected ComponentList childs = new ComponentList();

    /**
     * 缺省构造函数
     */
    public CompositeComponent() {

    }

    /**
     * 构造函数
     */
    public CompositeComponent(int id, String name, double price) {
        super(id, name, price);
    }

    /**
     * 添加子组件，对于没有子组件的AtomicComponent如内存条，调用这个方法应该抛出UnsupportedOperationException.
     *
     * @param component 添加子组件
     */
    @Override
    public void add(Component component) throws UnsupportedOperationException {
        childs.add(component);
    }

    /**
     * 计算组件的价格。
     *
     * @return 组件的价格
     */
    @Override
    public double calcPrice() {
        double priceAll=0;
        for(Component c:this.childs){
            priceAll+=c.getPrice();
        }
        return priceAll;
    }

    /**
     * 返回组件的迭代器
     *
     * @return 迭代器
     */
    @Override
    public Iterator iterator() {
        return new CompositeIterator(this.childs);
    }

    /**
     * 删除子组件，对于没有子组件的AtomicComponent如内存条，调用这个方法应该抛出UnsupportedOperationException .
     *
     * @param component 子组件
     */
    @Override
    public void remove(Component component) throws UnsupportedOperationException {
        childs.remove(component);
        this.price -= component.getPrice();

    }
    public String toString(){
        StringBuffer stringBuffer=new StringBuffer();
        stringBuffer.append(super.toString()+" have: \n");
        for(Component c: this.childs){
            stringBuffer.append(c.toString()+"\n");
        }
        return new String(stringBuffer);
    }
}
