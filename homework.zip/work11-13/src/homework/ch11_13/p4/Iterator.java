package homework.ch11_13.p4;

public interface Iterator {
    /**
     * @return 是否还有元素
     */
    boolean hasNext();

    /**
     * @return 获取下一个组件
     */
    Component next();

}
