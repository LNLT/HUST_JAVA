package homework.ch11_13.p4;

import java.util.ArrayList;
import java.util.List;

public class CompositeIterator implements Iterator{
    /**
     * 保存遍历到的每个节点的迭代器的列表
     */
    protected List<Iterator> iterators=new ArrayList<Iterator>();

    /**
     * 构造函数
     */
    public CompositeIterator(Iterator iterator){
        iterators.add(iterator);
    }

    /**
     * @return 是否还有元素
     */
    @Override
    public boolean hasNext(){
        if(iterators.isEmpty()){
            return false;
        }
        Iterator iterator = iterators.get(0);
        if(!iterator.hasNext()){
            iterators.remove(0);
            return hasNext();
        }else{
            return true;
        }
    }

    /**
     * @return 获取下一个组件
     */
    @Override
    public Component next(){
        if(hasNext()){
            Iterator iterator = iterators.get(0);
            Component component = (Component)iterator.next();
            iterators.add(component.iterator());
            return component;
        }
        return null;
    }
}
