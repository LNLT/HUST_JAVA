package hust.cs.ltt;

import java.util.Scanner;

public class test {
    public static void main(String[] args){
        System.out.println("请输入row：");
        Scanner input=new Scanner(System.in);
        int row=input.nextInt();
        char ok='\u0000';
        if(row>0){
            printArray(creatArray(row));
        }
        else{
            System.out.println("row输入错误");
        }
    }
    /**
     * 创建一个不规则的二维数组
     * 第一行row列
     * 第二行row-1列
     * ......
     * 最后一行1列
     * 数组元素都为默认值
     *
     * @param row：行数
     * @return 创建好的不规则数组
     */
    public static int[][] creatArray(int row) {
        int[][] list = new int[row][];
        for (int i = 0; i < row; i++) {
            list[i]=new int [row-i];
        }
        return list;
    }

    /**
     * 逐行打印出二维数组，数组元素之间以空格分开
     *
     * @param a:二位数组
     */
    public static void printArray(int[][] a) {
        for(int[] list:a){
            for(int num:list){
                System.out.print(num+" ");
            }
            System.out.print("\n");
        }

    }
}
