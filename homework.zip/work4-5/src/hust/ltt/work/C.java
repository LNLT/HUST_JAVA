package hust.ltt.work;

class ok {
    public static void main(String[] args) {
        String s = "null";
        if(s == null) System.out.print("a");
        else
            if(s.length() == 0)
                System.out.print("b");
            else
                System.out.print("c");
    }
}
