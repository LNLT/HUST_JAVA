package hust.ltt.work;

import java.util.Locale;
import java.util.Scanner;

/**
 * 统计字符串中每个字母出现的次数，大小写不敏感
 */
public class number {
    public static void main(String[] args){
        System.out.println("Enter a English string:");
        Scanner input = new Scanner(System.in);
        String s = input.next().toLowerCase();
        int [] count = new int[26];
        int i;
        for(i = 0;i < s.length();i++){
            int num = s.charAt(i)-'a';
            if(num>=0&&num<26)
                count[num]++;
        }
        i=0;
        for(int a:count){
            System.out.print((char)('a'+i)+":"+a+" ");
            i++;
        }
    }
}
