package hust.ltt.work;
/**
 * 随机生成三个大写字母和四个数字作为车牌号
 */
public class car_num {
    public static void main(String[] args){
        for(int i=0;i<5;i++){
            char ok1 = (char)('A'+(int)(Math.random()*('Z'-'A'+1)));
            char ok2 = (char)('A'+(int)(Math.random()*('Z'-'A'+1)));
            char ok3 = (char)('A'+(int)(Math.random()*('Z'-'A'+1)));
            int num1 = (int)(Math.random()*10);
            int num2 = (int)(Math.random()*10);
            int num3 = (int)(Math.random()*10);
            int num4 = (int)(Math.random()*10);
            System.out.printf("%c%c%c%d%d%d%d\n",ok1,ok2,ok3,num1,num2,num3,num4);
        }

    }
}
