package hust.cs.ltt.P2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class TwoTuple<T1 extends Comparable, T2 extends Comparable> implements Comparable {
    private T1 first;
    private T2 second;

    public TwoTuple() {

    }

    public TwoTuple(T1 first, T2 second) {
        this.first = first;
        this.second = second;
    }

    @Override
    public int compareTo(Object obj) {
        //实现comparable接口，其中因为first和first要比较，且继承多个接口不能写implements Comparable<T1>,Comparable<T2>;
        //所以只能将T1,T2变成comparable的子类
        if (obj instanceof TwoTuple) {
            TwoTuple<T1, T2> tuple = (TwoTuple<T1, T2>) obj;
            if (!tuple.first.equals(this.first)) {
                return this.first.compareTo(tuple.first);
            } else {
                return this.second.compareTo(tuple.second);
            }
        }
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof TwoTuple) {//进行类型判断
            TwoTuple<T1, T2> tuple = (TwoTuple<T1, T2>) obj;
            return this.first.equals(tuple.first) && this.second.equals(tuple.second);
        }
        return false;
    }

    @Override
    public String toString() {
        return "(" + this.first.toString() + "," + this.second.toString() + ")";
    }

    /**
     * second的getter方法
     */
    public T1 getterT1() {
        return this.first;
    }

    /**
     * first的getter方法
     */
    public T2 getterT2() {
        return this.second;
    }

    /**
     * first的setter方法
     */
    public void setterT1(T1 t1) {
        this.first = t1;
    }

    /**
     * second的setter方法
     */
    public void setterT2(T2 t2) {
        this.second = t2;
    }

}

public class test {
    public static void main(String[] args) {

        TwoTuple<Integer, String> twoTuple1 = new TwoTuple<>(1, "ccc");
        TwoTuple<Integer, String> twoTuple2 = new TwoTuple<>(1, "bbb");
        TwoTuple<Integer, String> twoTuple3 = new TwoTuple<>(1, "aaa");
        TwoTuple<Integer, String> twoTuple4 = new TwoTuple<>(2, "ccc");
        TwoTuple<Integer, String> twoTuple5 = new TwoTuple<>(2, "bbb");
        TwoTuple<Integer, String> twoTuple6 = new TwoTuple<>(2, "aaa");
        List<TwoTuple<Integer, String>> list = new ArrayList<>();
        list.add(twoTuple1);
        list.add(twoTuple2);
        list.add(twoTuple3);
        list.add(twoTuple4);
        list.add(twoTuple5);
        list.add(twoTuple6);

        //测试equals，contains方法是基于equals方法结果来判断
        TwoTuple<Integer, String> twoTuple10 = new TwoTuple<>(1, "ccc"); //内容=twoTuple1
        System.out.println(twoTuple1.equals(twoTuple10)); //应该为true
        if (!list.contains(twoTuple10)) {
            list.add(twoTuple10);  //这时不应该重复加入
        }

        //sort方法是根据元素的compareTo方法结果进行排序，课测试compareTo方法是否实现正确
        Collections.sort(list);


        for (TwoTuple<Integer, String> t : list) {
            System.out.println(t);
        }

        TwoTuple<TwoTuple<Integer, String>, TwoTuple<Integer, String>> tt1 =
                new TwoTuple<>(new TwoTuple<>(1, "aaa"), new TwoTuple<>(1, "bbb"));
        TwoTuple<TwoTuple<Integer, String>, TwoTuple<Integer, String>> tt2 =
                new TwoTuple<>(new TwoTuple<>(1, "aaa"), new TwoTuple<>(2, "bbb"));
        System.out.println(tt1.compareTo(tt2)); //输出-1
        System.out.println(tt1);

    }
}
